/* =============================================================
   data/units.js  –  Struktur der Lernbereiche
   -------------------------------------------------------------
   HIER ANPASSEN, sobald die echten Unit-Titel aus dem Schulbuch
   vorliegen:  title / titleDe / topics / titleConfirmed.
   Die App liest ALLES aus dieser Datei – nichts anderes muss
   geaendert werden, wenn eine Unit umbenannt oder ergaenzt wird.

   titleConfirmed:false  ->  die App zeigt intern den Hinweis
   "Titel noch nicht bestaetigt" im Elternbereich an.
   ============================================================= */
(function (w) {
  var D = w.DATA = w.DATA || {};

  D.meta = {
    course: 'Access 1 – Allgemeine Ausgabe 2022 (Cornelsen)',
    grade: '5. Schuljahr',
    isbn: '978-3-06-033978-5',
    disclaimer: 'Eigenstaendige Lern-App. Orientiert sich an Themen- und ' +
      'Grammatikbereichen des Lehrwerks. Keine Inhalte aus dem Schulbuch uebernommen.',
    version: '1.0.0'
  };

  D.units = [
    {
      id: 'u0', no: 0,
      title: 'Here we go',
      titleDe: 'Los geht’s',
      titleConfirmed: false,
      color: '#0EA5E9',
      intro: 'Sich vorstellen, Zahlen, Farben, Tiere, Wochentage',
      topics: ['Begrüßung & Vorstellen', 'Zahlen 1–100', 'Farben', 'Wochentage', 'Tiere', 'Im Klassenzimmer'],
      grammar: ['g_be_short']
    },
    {
      id: 'u1', no: 1,
      title: 'The first day at school',
      titleDe: 'Der erste Schultag',
      titleConfirmed: false,
      color: '#2563EB',
      intro: 'Schule, Schulsachen, Uhrzeit, Monate',
      topics: ['Schule & Schulsachen', 'Uhrzeit', 'Monate & Ordnungszahlen', 'Klassenzimmersprache', 'Das Alphabet'],
      grammar: ['g_be', 'g_pronouns', 'g_article', 'g_there', 'g_can', 'g_qwords']
    },
    {
      id: 'u2', no: 2,
      title: 'Homes and families',
      titleDe: 'Zuhause und Familie',
      titleConfirmed: false,
      color: '#7C3AED',
      intro: 'Familie, Wohnung, Essen und Trinken, Tagesablauf',
      topics: ['Familie', 'Haus & Zimmer', 'Essen und Trinken', 'Tagesablauf'],
      grammar: ['g_havegot', 'g_simplepresent', 'g_possessive', 'g_genitive', 'g_this_that']
    },
    {
      id: 'u3', no: 3,
      title: 'Clubs and hobbies',
      titleDe: 'Clubs und Hobbys',
      titleConfirmed: false,
      color: '#16A34A',
      intro: 'Hobbys, Sport, AGs, wie oft man etwas macht',
      topics: ['Hobbys & Freizeit', 'Sport', 'Schul-AGs', 'Häufigkeit'],
      grammar: ['g_sp_questions', 'g_frequency', 'g_plural', 'g_object_pron', 'g_much_many']
    },
    {
      id: 'u4', no: 4,
      title: 'Weekends',
      titleDe: 'Wochenende',
      titleConfirmed: false,
      color: '#EA580C',
      intro: 'Wochenende, Ausflüge, über Vergangenes sprechen',
      topics: ['Wochenendaktivitäten', 'Orte in der Stadt', 'Ausflüge', 'Über Vergangenes sprechen'],
      grammar: ['g_was_were', 'g_past_regular', 'g_past_irregular', 'g_past_neg_q']
    },
    {
      id: 'u5', no: 5,
      title: 'By the sea',
      titleDe: 'Am Meer',
      titleConfirmed: false,
      color: '#0891B2',
      intro: 'Am Meer, Wetter, beschreiben was gerade passiert',
      topics: ['Am Strand / Meer', 'Wetter', 'Gefühle', 'Beschreiben was gerade passiert'],
      grammar: ['g_progressive', 'g_prog_vs_simple', 'g_some_any']
    }
  ];

  /* Reihenfolge und Beschriftung der Lektionstypen innerhalb einer Unit. */
  D.lessonTypes = [
    { type: 'vocabulary', icon: '📚', label: 'Vocabulary', sub: 'Neue Wörter lernen' },
    { type: 'grammar',    icon: '🧩', label: 'Grammar',    sub: 'Grammatik verstehen und üben' },
    { type: 'listening',  icon: '👂', label: 'Listening',  sub: 'Hörverständnis' },
    { type: 'reading',    icon: '📖', label: 'Reading',    sub: 'Leseverständnis' },
    { type: 'speaking',   icon: '💬', label: 'Speaking',   sub: 'Nachsprechen & Aussprache' },
    { type: 'writing',    icon: '✍️', label: 'Writing',    sub: 'Eigene Sätze schreiben' },
    { type: 'everyday',   icon: '🌍', label: 'Everyday English', sub: 'Alltagsenglisch' },
    { type: 'challenge',  icon: '🏆', label: 'Unit Challenge',   sub: 'Abschlusstest' }
  ];

  /* Levelsystem – haengt ausschliesslich an den XP. */
  D.levels = [
    { lvl: 1, name: 'Beginner',        xp: 0 },
    { lvl: 2, name: 'Explorer',        xp: 250 },
    { lvl: 3, name: 'English Starter', xp: 700 },
    { lvl: 4, name: 'English Player',  xp: 1500 },
    { lvl: 5, name: 'English Pro',     xp: 2800 },
    { lvl: 6, name: 'English Master',  xp: 4800 },
    { lvl: 7, name: 'English Legend',  xp: 8000 }
  ];

  D.xp = {
    wordLearned: 5, correct: 5, streak5: 10,
    lessonDone: 25, unitDone: 100, testPassed: 150, dailyMission: 75
  };

  D.achievements = [
    { id: 'a_xp100',   icon: '🏆', name: 'First 100 XP',       desc: 'Sammle 100 XP.' },
    { id: 'a_xp1000',  icon: '💎', name: '1000 XP',            desc: 'Sammle 1.000 XP.' },
    { id: 'a_streak3', icon: '🔥', name: '3 Day Streak',       desc: 'Lerne 3 Tage hintereinander.' },
    { id: 'a_streak7', icon: '🔥', name: '7 Day Streak',       desc: 'Lerne 7 Tage hintereinander.' },
    { id: 'a_streak30',icon: '☄️', name: '30 Day Streak',      desc: 'Lerne 30 Tage hintereinander.' },
    { id: 'a_perfect', icon: '🎯', name: 'Perfect Quiz',       desc: 'Beende eine Lektion ohne Fehler.' },
    { id: 'a_words50', icon: '📗', name: '50 Words',           desc: '50 Wörter mindestens einmal richtig.' },
    { id: 'a_words200',icon: '📘', name: '200 Words',          desc: '200 Wörter mindestens einmal richtig.' },
    { id: 'a_master25',icon: '⭐', name: 'Vocabulary Master',        desc: '25 Wörter gemeistert.' },
    { id: 'a_grammar', icon: '🧠', name: 'Grammar Hero',       desc: 'Schließe 5 Grammatik-Lektionen ab.' },
    { id: 'a_unit1',   icon: '🎖️', name: 'Unit Champion',desc: 'Schließe eine komplette Unit ab.' },
    { id: 'a_test',    icon: '📜', name: 'Test Ready',         desc: 'Bestehe einen Unit-Test mit 80 % oder mehr.' },
    { id: 'a_games',   icon: '🎮', name: 'Game On',            desc: 'Spiele alle drei Spiele.' },
    { id: 'a_mission', icon: '🎯', name: 'Mission Complete',   desc: 'Schaffe 5 Tagesmissionen.' }
  ];
})(window);
